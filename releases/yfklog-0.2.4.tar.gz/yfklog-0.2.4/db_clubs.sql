CREATE TABLE clubs (
  `club` varchar(30) NOT NULL default '',
  `nr` varchar(6) NOT NULL default '',
  `call` varchar(6) NOT NULL default ''
) TYPE=MyISAM;
