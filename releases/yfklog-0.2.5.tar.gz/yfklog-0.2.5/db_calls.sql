CREATE TABLE `calls` (
  `CALL` varchar(12) NOT NULL default '',
  `NAME` varchar(12) default '',
  `QTH` varchar(15) default '',
  PRIMARY KEY  (`CALL`)
) TYPE=MyISAM;

