CREATE TABLE YFKconfig (
  `Name` varchar(50) NOT NULL default '',
  `Value` varchar(50) NOT NULL default ''
) TYPE=MyISAM;

